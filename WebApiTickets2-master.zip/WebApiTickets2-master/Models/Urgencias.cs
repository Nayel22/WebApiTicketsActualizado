﻿namespace WebApiTikects.Models
{
    public class Urgencias
    {
        public int ur_identificador { get; set; }
        public string ur_nivel { get; set; }
    }
}
