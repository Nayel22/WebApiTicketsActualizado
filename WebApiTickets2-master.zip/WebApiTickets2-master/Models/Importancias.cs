﻿namespace WebApiTikects.Models
{
    public class Importancias
    {
        public int im_identificador { get; set; }
        public string im_nivel { get; set; }
    }
}
