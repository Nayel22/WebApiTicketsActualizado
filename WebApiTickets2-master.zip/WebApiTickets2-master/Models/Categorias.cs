﻿namespace WebApiTikects.Models
{
    public class Categorias
    {
        public int ca_identificador { get; set; }
        public string ca_nombre { get; set; }
    }
}
